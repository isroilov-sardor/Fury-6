"use client"

import { useState } from "react"
import { CameraModule } from "./camera-module"
import type { ThreeEvent } from "@react-three/fiber"

interface HexapodBodyProps {
  onHover?: (id: string, hovered: boolean) => void
  onClick?: (id: string) => void
  hoveredPart: string | null
}

export function HexapodBody({
  onHover,
  onClick,
  hoveredPart,
}: HexapodBodyProps) {
  const [hovered, setHovered] = useState(false)

  const handlePointerOver = (e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation()
    setHovered(true)
    onHover?.("body_chassis", true)
    document.body.style.cursor = "pointer"
  }

  const handlePointerOut = (e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation()
    setHovered(false)
    onHover?.("body_chassis", false)
    document.body.style.cursor = "auto"
  }

  const handleClick = (e: ThreeEvent<MouseEvent>) => {
    e.stopPropagation()
    onClick?.("body_chassis")
  }

  const chassisColor =
    hovered || hoveredPart === "body_chassis" ? "#4a5568" : "#2d2d44"
  const plateColor =
    hovered || hoveredPart === "body_chassis" ? "#5a6578" : "#3d3d54"

  return (
    <group>
      {/* ===== MAIN CHASSIS - Hexagonal body plate ===== */}
      {/* Bottom plate */}
      <mesh
        position={[0, -0.06, 0]}
        onPointerOver={handlePointerOver}
        onPointerOut={handlePointerOut}
        onClick={handleClick}
      >
        <cylinderGeometry args={[0.85, 0.9, 0.06, 6]} />
        <meshStandardMaterial
          color={chassisColor}
          metalness={0.75}
          roughness={0.25}
        />
      </mesh>

      {/* Top plate */}
      <mesh position={[0, 0.06, 0]}>
        <cylinderGeometry args={[0.8, 0.85, 0.06, 6]} />
        <meshStandardMaterial
          color={plateColor}
          metalness={0.7}
          roughness={0.3}
        />
      </mesh>

      {/* Middle spacers (hex standoffs) */}
      {Array.from({ length: 6 }).map((_, i) => {
        const angle = (i / 6) * Math.PI * 2 + Math.PI / 6
        const r = 0.6
        return (
          <mesh
            key={`spacer-${i}`}
            position={[Math.cos(angle) * r, 0, Math.sin(angle) * r]}
          >
            <cylinderGeometry args={[0.03, 0.03, 0.12, 6]} />
            <meshStandardMaterial
              color="#aaaacc"
              metalness={0.9}
              roughness={0.1}
            />
          </mesh>
        )
      })}

      {/* Mounting holes on top plate */}
      {Array.from({ length: 12 }).map((_, i) => {
        const angle = (i / 12) * Math.PI * 2
        const r = 0.5
        return (
          <mesh
            key={`mount-${i}`}
            position={[Math.cos(angle) * r, 0.091, Math.sin(angle) * r]}
          >
            <cylinderGeometry args={[0.018, 0.018, 0.01, 8]} />
            <meshStandardMaterial
              color="#777799"
              metalness={0.9}
              roughness={0.1}
            />
          </mesh>
        )
      })}

      {/* Ventilation slots on top */}
      {Array.from({ length: 3 }).map((_, i) => (
        <mesh key={`vent-${i}`} position={[0, 0.092, -0.15 + i * 0.15]}>
          <boxGeometry args={[0.4, 0.005, 0.04]} />
          <meshStandardMaterial
            color="#1a1a2e"
            metalness={0.5}
            roughness={0.5}
          />
        </mesh>
      ))}

      {/* ===== ELECTRONICS BAY ===== */}
      {/* Battery pack */}
      <mesh position={[0, 0.15, -0.15]}>
        <boxGeometry args={[0.35, 0.1, 0.2]} />
        <meshStandardMaterial color="#cc4488" metalness={0.3} roughness={0.6} />
      </mesh>
      {/* Battery cells visible */}
      <mesh position={[-0.08, 0.16, -0.15]} rotation={[0, 0, Math.PI / 2]}>
        <cylinderGeometry args={[0.04, 0.04, 0.15, 12]} />
        <meshStandardMaterial color="#dd5599" metalness={0.4} roughness={0.5} />
      </mesh>
      <mesh position={[0.08, 0.16, -0.15]} rotation={[0, 0, Math.PI / 2]}>
        <cylinderGeometry args={[0.04, 0.04, 0.15, 12]} />
        <meshStandardMaterial color="#dd5599" metalness={0.4} roughness={0.5} />
      </mesh>

      {/* Controller board */}
      <mesh position={[0, 0.12, 0.15]}>
        <boxGeometry args={[0.4, 0.02, 0.25]} />
        <meshStandardMaterial color="#1a5c2e" metalness={0.3} roughness={0.7} />
      </mesh>
      {/* IC chips on board */}
      <mesh position={[0.05, 0.135, 0.12]}>
        <boxGeometry args={[0.08, 0.015, 0.08]} />
        <meshStandardMaterial color="#111111" metalness={0.5} roughness={0.5} />
      </mesh>
      <mesh position={[-0.08, 0.135, 0.18]}>
        <boxGeometry args={[0.06, 0.01, 0.06]} />
        <meshStandardMaterial color="#111111" metalness={0.5} roughness={0.5} />
      </mesh>

      {/* ===== CAMERA MODULE ON TOP ===== */}
      <CameraModule
        id="body_camera"
        position={[0, 0.28, 0]}
        onHover={onHover}
        onClick={onClick}
        isHighlighted={hoveredPart === "body_camera"}
      />

      {/* Camera mount post */}
      <mesh position={[0, 0.2, 0]}>
        <cylinderGeometry args={[0.04, 0.05, 0.15, 8]} />
        <meshStandardMaterial color="#444466" metalness={0.8} roughness={0.2} />
      </mesh>

      {/* Power switch */}
      <mesh position={[0.4, 0, -0.5]} rotation={[Math.PI / 2, 0, 0]}>
        <boxGeometry args={[0.08, 0.04, 0.05]} />
        <meshStandardMaterial color="#cc3333" metalness={0.5} roughness={0.4} />
      </mesh>

      {/* USB port */}
      <mesh position={[-0.35, -0.02, -0.55]} rotation={[Math.PI / 2, 0, 0]}>
        <boxGeometry args={[0.12, 0.04, 0.06]} />
        <meshStandardMaterial color="#333344" metalness={0.7} roughness={0.3} />
      </mesh>

      {/* Leg mounting brackets on body edges (6) */}
      {Array.from({ length: 6 }).map((_, i) => {
        const angle = (i / 6) * Math.PI * 2
        const r = 0.88
        return (
          <group key={`mount-bracket-${i}`}>
            <mesh
              position={[Math.cos(angle) * r, 0, Math.sin(angle) * r]}
              rotation={[0, -angle, 0]}
            >
              <boxGeometry args={[0.2, 0.14, 0.18]} />
              <meshStandardMaterial
                color="#3a3a55"
                metalness={0.8}
                roughness={0.2}
              />
            </mesh>
            {/* Mounting bolts */}
            <mesh
              position={[
                Math.cos(angle) * (r + 0.05),
                0.08,
                Math.sin(angle) * (r + 0.05),
              ]}
            >
              <cylinderGeometry args={[0.015, 0.015, 0.02, 6]} />
              <meshStandardMaterial
                color="#ccccdd"
                metalness={0.9}
                roughness={0.1}
              />
            </mesh>
          </group>
        )
      })}
    </group>
  )
}
