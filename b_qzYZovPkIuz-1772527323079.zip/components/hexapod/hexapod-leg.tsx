"use client"

import { useRef } from "react"
import type { Group } from "three"
import { ServoMotor } from "./servo-motor"
import { LegSegment } from "./leg-segment"

export interface JointAngles {
  coxa: number // Joint 1 - horizontal rotation at body
  femur: number // Joint 2 - vertical rotation at knee
  tibia: number // Joint 3 - vertical rotation at ankle
}

export interface LegConfig {
  legIndex: number // 0-5 (L1, R1, L2, R2, L3, R3)
  legName: string
  mountAngle: number // angle around body where leg attaches (radians)
  mountPosition: [number, number, number]
  side: "left" | "right"
}

interface HexapodLegProps {
  config: LegConfig
  jointAngles: JointAngles
  selectedJoint: string | null
  hoveredPart: string | null
  onJointHover: (id: string, hovered: boolean) => void
  onJointClick: (id: string) => void
  onPartHover: (id: string, hovered: boolean) => void
  onPartClick: (id: string) => void
}

// Segment lengths (based on real hexapod dimensions)
const COXA_LENGTH = 0.5 // Short segment from body
const FEMUR_LENGTH = 0.8 // Middle segment
const TIBIA_LENGTH = 0.9 // Lower segment (longest)

export function HexapodLeg({
  config,
  jointAngles,
  selectedJoint,
  hoveredPart,
  onJointHover,
  onJointClick,
  onPartHover,
  onPartClick,
}: HexapodLegProps) {
  const legGroupRef = useRef<Group>(null)
  const { legIndex, mountAngle, mountPosition } = config

  const prefix = `leg${legIndex}`

  return (
    <group
      ref={legGroupRef}
      position={mountPosition}
      rotation={[0, mountAngle, 0]}
    >
      {/* ===== JOINT 1: COXA (body-to-leg horizontal rotation) ===== */}
      <group rotation={[0, jointAngles.coxa, 0]}>
        {/* Coxa Servo Motor */}
        <ServoMotor
          id={`${prefix}_servo_coxa`}
          position={[0.15, 0, 0]}
          rotation={[0, 0, 0]}
          isHighlighted={selectedJoint === `${prefix}_joint_coxa`}
          onHover={onJointHover}
          onClick={() => onJointClick(`${prefix}_joint_coxa`)}
        />

        {/* Coxa Bracket (short segment) */}
        <LegSegment
          id={`${prefix}_coxa`}
          length={COXA_LENGTH}
          width={0.14}
          position={[0.35, 0, 0]}
          variant="coxa"
          isHighlighted={hoveredPart === `${prefix}_coxa`}
          onHover={onPartHover}
          onClick={onPartClick}
        />

        {/* ===== JOINT 2: FEMUR (coxa-to-femur vertical rotation) ===== */}
        <group position={[0.35 + COXA_LENGTH, 0, 0]}>
          <group rotation={[0, 0, jointAngles.femur]}>
            {/* Femur Servo Motor */}
            <ServoMotor
              id={`${prefix}_servo_femur`}
              position={[0.05, 0.1, 0]}
              rotation={[0, 0, Math.PI / 2]}
              isHighlighted={selectedJoint === `${prefix}_joint_femur`}
              onHover={onJointHover}
              onClick={() => onJointClick(`${prefix}_joint_femur`)}
            />

            {/* Femur Bracket (middle segment) */}
            <LegSegment
              id={`${prefix}_femur`}
              length={FEMUR_LENGTH}
              width={0.12}
              position={[0.15, -0.05, 0]}
              rotation={[0, 0, -0.3]}
              variant="femur"
              isHighlighted={hoveredPart === `${prefix}_femur`}
              onHover={onPartHover}
              onClick={onPartClick}
            />

            {/* ===== JOINT 3: TIBIA (femur-to-tibia vertical rotation) ===== */}
            <group
              position={[
                0.15 + Math.cos(-0.3) * FEMUR_LENGTH,
                -0.05 + Math.sin(-0.3) * FEMUR_LENGTH,
                0,
              ]}
            >
              <group rotation={[0, 0, jointAngles.tibia]}>
                {/* Tibia Servo Motor */}
                <ServoMotor
                  id={`${prefix}_servo_tibia`}
                  position={[0.05, 0.08, 0]}
                  rotation={[0, 0, Math.PI / 2]}
                  isHighlighted={selectedJoint === `${prefix}_joint_tibia`}
                  onHover={onJointHover}
                  onClick={() => onJointClick(`${prefix}_joint_tibia`)}
                />

                {/* Tibia Bracket (lower segment - longest) */}
                <LegSegment
                  id={`${prefix}_tibia`}
                  length={TIBIA_LENGTH}
                  width={0.1}
                  position={[0.15, -0.05, 0]}
                  rotation={[0, 0, -0.5]}
                  variant="tibia"
                  isHighlighted={hoveredPart === `${prefix}_tibia`}
                  onHover={onPartHover}
                  onClick={onPartClick}
                />

                {/* Foot tip - rubber end */}
                <mesh
                  position={[
                    0.15 + Math.cos(-0.5) * TIBIA_LENGTH + 0.02,
                    -0.05 + Math.sin(-0.5) * TIBIA_LENGTH - 0.02,
                    0,
                  ]}
                >
                  <sphereGeometry args={[0.04, 12, 12]} />
                  <meshStandardMaterial
                    color="#222222"
                    metalness={0.2}
                    roughness={0.9}
                  />
                </mesh>
              </group>
            </group>
          </group>
        </group>
      </group>
    </group>
  )
}

export { COXA_LENGTH, FEMUR_LENGTH, TIBIA_LENGTH }
