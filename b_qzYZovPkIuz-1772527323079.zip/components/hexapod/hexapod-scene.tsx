"use client"

import { Suspense, useState, useCallback } from "react"
import { Canvas } from "@react-three/fiber"
import { OrbitControls, Text } from "@react-three/drei"
import { HexapodAssembly } from "./hexapod-assembly"
import { GridAxes } from "./grid-axes"
import { JointPanel } from "./joint-panel"
import type { JointAngles } from "./hexapod-leg"
import { LEG_CONFIGS } from "./hexapod-assembly"

// Default standing pose for all legs
const DEFAULT_JOINT_ANGLES: JointAngles = {
  coxa: 0,
  femur: -0.3,
  tibia: -0.6,
}

function createDefaultAnglesMap(): Record<number, JointAngles> {
  const map: Record<number, JointAngles> = {}
  for (let i = 0; i < 6; i++) {
    map[i] = { ...DEFAULT_JOINT_ANGLES }
  }
  return map
}

function SceneLabels() {
  return (
    <group>
      {/* Leg labels floating above each leg attachment */}
      {LEG_CONFIGS.map((config) => {
        const [x, , z] = config.mountPosition
        const labelOffset = 1.8
        return (
          <Text
            key={`label-${config.legIndex}`}
            position={[x * labelOffset, 2.8, z * labelOffset]}
            fontSize={0.18}
            color="#888888"
            font="/fonts/GeistMono-Regular.ttf"
            anchorX="center"
            anchorY="middle"
          >
            {config.legName.split(" (")[0]}
          </Text>
        )
      })}

      {/* Title */}
      <Text
        position={[0, 4.2, 0]}
        fontSize={0.25}
        color="#666666"
        font="/fonts/Geist-Bold.ttf"
        anchorX="center"
        anchorY="middle"
      >
        HEXAPOD ROBOT - 3D VIEWER
      </Text>
    </group>
  )
}

export function HexapodScene() {
  const [jointAnglesMap, setJointAnglesMap] = useState<
    Record<number, JointAngles>
  >(createDefaultAnglesMap)
  const [selectedJoint, setSelectedJoint] = useState<string | null>(null)
  const [hoveredPart, setHoveredPart] = useState<string | null>(null)

  const handleJointAngleChange = useCallback(
    (legIndex: number, joint: keyof JointAngles, value: number) => {
      setJointAnglesMap((prev) => ({
        ...prev,
        [legIndex]: {
          ...prev[legIndex],
          [joint]: value,
        },
      }))
    },
    []
  )

  const handleResetAll = useCallback(() => {
    setJointAnglesMap(createDefaultAnglesMap())
    setSelectedJoint(null)
  }, [])

  const handleJointHover = useCallback((id: string, hovered: boolean) => {
    setHoveredPart(hovered ? id : null)
  }, [])

  const handleJointClick = useCallback((id: string) => {
    setSelectedJoint((prev) => (prev === id ? null : id))
  }, [])

  const handlePartHover = useCallback((id: string, hovered: boolean) => {
    setHoveredPart(hovered ? id : null)
  }, [])

  const handlePartClick = useCallback((id: string) => {
    setSelectedJoint((prev) => (prev === id ? null : id))
  }, [])

  return (
    <div className="relative h-screen w-full" style={{ background: "#0d0d1a" }}>
      <Canvas
        camera={{ position: [6, 5, 6], fov: 50, near: 0.1, far: 100 }}
        shadows
        gl={{ antialias: true }}
      >
        {/* Background color - Blender-like dark void */}
        <color attach="background" args={["#1a1a2e"]} />
        <fog attach="fog" args={["#1a1a2e", 15, 35]} />

        {/* Lighting setup */}
        <ambientLight intensity={0.4} />
        <directionalLight
          position={[5, 8, 5]}
          intensity={1.2}
          castShadow
          shadow-mapSize={[2048, 2048]}
        />
        <directionalLight position={[-3, 5, -3]} intensity={0.5} />
        <pointLight position={[0, 3, 0]} intensity={0.3} color="#4488ff" />

        <Suspense fallback={null}>
          {/* Grid and axes (Blender style) */}
          <GridAxes />

          {/* The hexapod robot */}
          <HexapodAssembly
            jointAnglesMap={jointAnglesMap}
            selectedJoint={selectedJoint}
            hoveredPart={hoveredPart}
            onJointHover={handleJointHover}
            onJointClick={handleJointClick}
            onPartHover={handlePartHover}
            onPartClick={handlePartClick}
          />

          {/* Scene labels */}
          <SceneLabels />
        </Suspense>

        {/* Orbit controls */}
        <OrbitControls
          makeDefault
          enableDamping
          dampingFactor={0.1}
          minDistance={2}
          maxDistance={20}
          target={[0, 1.5, 0]}
        />
      </Canvas>

      {/* Joint control panel overlay */}
      <JointPanel
        jointAnglesMap={jointAnglesMap}
        selectedJoint={selectedJoint}
        hoveredPart={hoveredPart}
        onJointAngleChange={handleJointAngleChange}
        onResetAll={handleResetAll}
      />

      {/* View controls hint */}
      <div className="absolute bottom-4 left-4 rounded-lg border border-[#333] bg-[#1a1a2e]/90 px-4 py-3 backdrop-blur-sm">
        <div className="flex flex-col gap-1 text-[11px] text-[#666]">
          <span>
            <kbd className="rounded bg-[#2a2a3e] px-1.5 py-0.5 text-[#888]">
              LMB
            </kbd>{" "}
            Rotate
          </span>
          <span>
            <kbd className="rounded bg-[#2a2a3e] px-1.5 py-0.5 text-[#888]">
              RMB
            </kbd>{" "}
            Pan
          </span>
          <span>
            <kbd className="rounded bg-[#2a2a3e] px-1.5 py-0.5 text-[#888]">
              Scroll
            </kbd>{" "}
            Zoom
          </span>
          <span>
            <kbd className="rounded bg-[#2a2a3e] px-1.5 py-0.5 text-[#888]">
              Click
            </kbd>{" "}
            Select joint
          </span>
        </div>
      </div>

      {/* Axes indicator in corner */}
      <div className="absolute bottom-4 right-4 flex items-center gap-2 rounded-lg border border-[#333] bg-[#1a1a2e]/90 px-3 py-2 text-[11px] backdrop-blur-sm">
        <span className="font-bold text-[#ff4444]">X</span>
        <span className="font-bold text-[#44ff44]">Y</span>
        <span className="font-bold text-[#4488ff]">Z</span>
      </div>
    </div>
  )
}
