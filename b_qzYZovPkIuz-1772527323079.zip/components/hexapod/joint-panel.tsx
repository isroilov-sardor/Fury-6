"use client"

import { type JointAngles } from "./hexapod-leg"
import { LEG_CONFIGS } from "./hexapod-assembly"

interface JointPanelProps {
  jointAnglesMap: Record<number, JointAngles>
  selectedJoint: string | null
  hoveredPart: string | null
  onJointAngleChange: (legIndex: number, joint: keyof JointAngles, value: number) => void
  onResetAll: () => void
}

function radToDeg(rad: number): number {
  return Math.round((rad * 180) / Math.PI)
}

function degToRad(deg: number): number {
  return (deg * Math.PI) / 180
}

export function JointPanel({
  jointAnglesMap,
  selectedJoint,
  hoveredPart,
  onJointAngleChange,
  onResetAll,
}: JointPanelProps) {
  const getSelectedLegIndex = (): number | null => {
    if (!selectedJoint) return null
    const match = selectedJoint.match(/leg(\d+)/)
    return match ? parseInt(match[1]) : null
  }

  const selectedLegIndex = getSelectedLegIndex()

  return (
    <div className="absolute top-4 right-4 w-80 max-h-[calc(100vh-2rem)] overflow-y-auto rounded-lg border border-[#333] bg-[#1a1a2e]/95 text-[#e0e0e0] shadow-2xl backdrop-blur-sm">
      {/* Header */}
      <div className="border-b border-[#333] p-4">
        <h2 className="text-lg font-bold text-[#e0e0e0]">Hexapod Controller</h2>
        <p className="mt-1 text-xs text-[#888]">
          Click joints/servos to select. Drag sliders to move.
        </p>
      </div>

      {/* Hovered Part Info */}
      {hoveredPart && (
        <div className="border-b border-[#333] px-4 py-2">
          <span className="text-xs text-[#888]">Hovering: </span>
          <span className="text-xs font-mono text-[#4ecdc4]">{hoveredPart}</span>
        </div>
      )}

      {/* Selected Joint Info */}
      {selectedJoint && (
        <div className="border-b border-[#333] bg-[#ff6b35]/10 px-4 py-2">
          <span className="text-xs text-[#888]">Selected: </span>
          <span className="text-xs font-mono text-[#ff6b35]">{selectedJoint}</span>
        </div>
      )}

      {/* Leg Controls */}
      <div className="p-4">
        <div className="mb-3 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-[#aaa]">Joint Angles</h3>
          <button
            onClick={onResetAll}
            className="rounded bg-[#333] px-2 py-1 text-xs text-[#888] transition-colors hover:bg-[#444] hover:text-[#ccc]"
          >
            Reset All
          </button>
        </div>

        {LEG_CONFIGS.map((config) => {
          const angles = jointAnglesMap[config.legIndex] || {
            coxa: 0,
            femur: -0.3,
            tibia: -0.6,
          }
          const isSelected = selectedLegIndex === config.legIndex
          const prefix = `leg${config.legIndex}`

          return (
            <div
              key={config.legIndex}
              className={`mb-3 rounded-lg border p-3 transition-colors ${
                isSelected
                  ? "border-[#ff6b35]/50 bg-[#ff6b35]/5"
                  : "border-[#2a2a3e]"
              }`}
            >
              <div className="mb-2 flex items-center gap-2">
                <div
                  className={`h-2 w-2 rounded-full ${
                    config.side === "left" ? "bg-[#4ecdc4]" : "bg-[#ff6b9d]"
                  }`}
                />
                <span className="text-xs font-semibold text-[#ccc]">
                  {config.legName}
                </span>
              </div>

              {/* Coxa Joint */}
              <JointSlider
                label="J1 Coxa"
                id={`${prefix}_joint_coxa`}
                value={radToDeg(angles.coxa)}
                min={-90}
                max={90}
                selectedJoint={selectedJoint}
                onChange={(deg) =>
                  onJointAngleChange(config.legIndex, "coxa", degToRad(deg))
                }
              />

              {/* Femur Joint */}
              <JointSlider
                label="J2 Femur"
                id={`${prefix}_joint_femur`}
                value={radToDeg(angles.femur)}
                min={-90}
                max={90}
                selectedJoint={selectedJoint}
                onChange={(deg) =>
                  onJointAngleChange(config.legIndex, "femur", degToRad(deg))
                }
              />

              {/* Tibia Joint */}
              <JointSlider
                label="J3 Tibia"
                id={`${prefix}_joint_tibia`}
                value={radToDeg(angles.tibia)}
                min={-120}
                max={30}
                selectedJoint={selectedJoint}
                onChange={(deg) =>
                  onJointAngleChange(config.legIndex, "tibia", degToRad(deg))
                }
              />
            </div>
          )
        })}
      </div>

      {/* Legend */}
      <div className="border-t border-[#333] p-4">
        <h3 className="mb-2 text-xs font-semibold text-[#888]">Part IDs Reference</h3>
        <div className="grid grid-cols-2 gap-1 text-[10px] font-mono text-[#666]">
          <span>body_chassis</span>
          <span>body_camera</span>
          <span>legN_servo_coxa</span>
          <span>legN_servo_femur</span>
          <span>legN_servo_tibia</span>
          <span>legN_coxa</span>
          <span>legN_femur</span>
          <span>legN_tibia</span>
        </div>
      </div>
    </div>
  )
}

// Individual joint slider component
function JointSlider({
  label,
  id,
  value,
  min,
  max,
  selectedJoint,
  onChange,
}: {
  label: string
  id: string
  value: number
  min: number
  max: number
  selectedJoint: string | null
  onChange: (value: number) => void
}) {
  const isActive = selectedJoint === id

  return (
    <div className="mb-1.5 flex items-center gap-2">
      <span
        className={`w-16 text-[10px] font-mono ${
          isActive ? "text-[#ff6b35]" : "text-[#777]"
        }`}
      >
        {label}
      </span>
      <input
        type="range"
        min={min}
        max={max}
        value={value}
        onChange={(e) => onChange(parseInt(e.target.value))}
        className="h-1 flex-1 cursor-pointer appearance-none rounded-full bg-[#333] accent-[#ff6b35]"
      />
      <span className="w-10 text-right text-[10px] font-mono text-[#888]">
        {value}°
      </span>
    </div>
  )
}
