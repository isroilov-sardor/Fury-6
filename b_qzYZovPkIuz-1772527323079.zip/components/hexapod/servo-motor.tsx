"use client"

import { useRef, useState } from "react"
import type { Mesh } from "three"
import type { ThreeEvent } from "@react-three/fiber"

interface ServoMotorProps {
  id: string
  position?: [number, number, number]
  rotation?: [number, number, number]
  isHighlighted?: boolean
  onHover?: (id: string, hovered: boolean) => void
  onClick?: (id: string) => void
}

export function ServoMotor({
  id,
  position = [0, 0, 0],
  rotation = [0, 0, 0],
  isHighlighted = false,
  onHover,
  onClick,
}: ServoMotorProps) {
  const meshRef = useRef<Mesh>(null)
  const [hovered, setHovered] = useState(false)

  const handlePointerOver = (e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation()
    setHovered(true)
    onHover?.(id, true)
    document.body.style.cursor = "pointer"
  }

  const handlePointerOut = (e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation()
    setHovered(false)
    onHover?.(id, false)
    document.body.style.cursor = "auto"
  }

  const handleClick = (e: ThreeEvent<MouseEvent>) => {
    e.stopPropagation()
    onClick?.(id)
  }

  const bodyColor = hovered || isHighlighted ? "#ff6b35" : "#1a1a2e"
  const hornColor = hovered || isHighlighted ? "#ffaa00" : "#e0e0e0"

  return (
    <group position={position} rotation={rotation}>
      {/* Servo body - main rectangular casing */}
      <mesh
        ref={meshRef}
        onPointerOver={handlePointerOver}
        onPointerOut={handlePointerOut}
        onClick={handleClick}
      >
        <boxGeometry args={[0.4, 0.2, 0.2]} />
        <meshStandardMaterial
          color={bodyColor}
          metalness={0.7}
          roughness={0.3}
        />
      </mesh>

      {/* Servo mounting tabs */}
      <mesh position={[0, -0.1, -0.13]}>
        <boxGeometry args={[0.5, 0.03, 0.04]} />
        <meshStandardMaterial color="#333344" metalness={0.8} roughness={0.2} />
      </mesh>
      <mesh position={[0, -0.1, 0.13]}>
        <boxGeometry args={[0.5, 0.03, 0.04]} />
        <meshStandardMaterial color="#333344" metalness={0.8} roughness={0.2} />
      </mesh>

      {/* Servo output horn (round disc) */}
      <mesh position={[0.22, 0, 0]} rotation={[0, 0, Math.PI / 2]}>
        <cylinderGeometry args={[0.08, 0.08, 0.04, 16]} />
        <meshStandardMaterial
          color={hornColor}
          metalness={0.5}
          roughness={0.4}
        />
      </mesh>

      {/* Servo shaft */}
      <mesh position={[0.25, 0, 0]} rotation={[0, 0, Math.PI / 2]}>
        <cylinderGeometry args={[0.03, 0.03, 0.06, 12]} />
        <meshStandardMaterial color="#888888" metalness={0.9} roughness={0.1} />
      </mesh>

      {/* Wire connector */}
      <mesh position={[-0.22, 0.05, 0]}>
        <boxGeometry args={[0.04, 0.06, 0.1]} />
        <meshStandardMaterial color="#222222" metalness={0.3} roughness={0.7} />
      </mesh>

      {/* Label sticker on servo */}
      <mesh position={[0, 0.101, 0]}>
        <planeGeometry args={[0.25, 0.12]} />
        <meshStandardMaterial
          color="#2a2a4a"
          metalness={0.2}
          roughness={0.8}
        />
      </mesh>

      {/* Mounting screws (4 corners) */}
      {(
        [
          [0.2, -0.1, -0.14],
          [-0.2, -0.1, -0.14],
          [0.2, -0.1, 0.14],
          [-0.2, -0.1, 0.14],
        ] as [number, number, number][]
      ).map((pos, i) => (
        <mesh key={`screw-${i}`} position={pos}>
          <cylinderGeometry args={[0.015, 0.015, 0.04, 8]} />
          <meshStandardMaterial
            color="#aaaaaa"
            metalness={0.9}
            roughness={0.1}
          />
        </mesh>
      ))}
    </group>
  )
}
