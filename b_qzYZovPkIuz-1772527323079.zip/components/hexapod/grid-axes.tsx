"use client"

import { Text } from "@react-three/drei"

export function GridAxes() {
  const gridSize = 20
  const gridDivisions = 20

  return (
    <group>
      {/* Main grid (Blender-style) */}
      <gridHelper
        args={[gridSize, gridDivisions, "#555555", "#333333"]}
        position={[0, 0, 0]}
      />

      {/* Sub-grid for finer detail */}
      <gridHelper
        args={[gridSize, gridDivisions * 5, "transparent", "#1a1a1a"]}
        position={[0, 0.001, 0]}
      />

      {/* ===== X AXIS (Red) ===== */}
      <mesh position={[gridSize / 2, 0.01, 0]}>
        <boxGeometry args={[gridSize, 0.02, 0.02]} />
        <meshBasicMaterial color="#ff4444" />
      </mesh>
      <mesh position={[gridSize / 2 + 0.15, 0.01, 0]}>
        <coneGeometry args={[0.06, 0.2, 8]} />
        <meshBasicMaterial color="#ff4444" />
      </mesh>
      <Text
        position={[gridSize / 2 + 0.6, 0.15, 0]}
        fontSize={0.3}
        color="#ff4444"
        font="/fonts/Geist-Bold.ttf"
        anchorX="center"
        anchorY="middle"
      >
        X
      </Text>

      {/* Negative X */}
      <mesh position={[-gridSize / 2, 0.01, 0]}>
        <boxGeometry args={[gridSize, 0.015, 0.015]} />
        <meshBasicMaterial color="#ff4444" transparent opacity={0.3} />
      </mesh>

      {/* ===== Y AXIS (Green) - Up ===== */}
      <mesh position={[0, gridSize / 4, 0]}>
        <boxGeometry args={[0.02, gridSize / 2, 0.02]} />
        <meshBasicMaterial color="#44ff44" />
      </mesh>
      <group position={[0, gridSize / 4 + 0.15, 0]} rotation={[0, 0, Math.PI / 2]}>
        <mesh>
          <coneGeometry args={[0.06, 0.2, 8]} />
          <meshBasicMaterial color="#44ff44" />
        </mesh>
      </group>
      <Text
        position={[0, gridSize / 4 + 0.6, 0]}
        fontSize={0.3}
        color="#44ff44"
        font="/fonts/Geist-Bold.ttf"
        anchorX="center"
        anchorY="middle"
      >
        Y
      </Text>

      {/* ===== Z AXIS (Blue) ===== */}
      <mesh position={[0, 0.01, gridSize / 2]}>
        <boxGeometry args={[0.02, 0.02, gridSize]} />
        <meshBasicMaterial color="#4488ff" />
      </mesh>
      <group position={[0, 0.01, gridSize / 2 + 0.15]} rotation={[Math.PI / 2, 0, 0]}>
        <mesh rotation={[0, 0, Math.PI]}>
          <coneGeometry args={[0.06, 0.2, 8]} />
          <meshBasicMaterial color="#4488ff" />
        </mesh>
      </group>
      <Text
        position={[0, 0.15, gridSize / 2 + 0.6]}
        fontSize={0.3}
        color="#4488ff"
        font="/fonts/Geist-Bold.ttf"
        anchorX="center"
        anchorY="middle"
      >
        Z
      </Text>

      {/* Negative Z */}
      <mesh position={[0, 0.01, -gridSize / 2]}>
        <boxGeometry args={[0.015, 0.015, gridSize]} />
        <meshBasicMaterial color="#4488ff" transparent opacity={0.3} />
      </mesh>

      {/* Origin marker */}
      <mesh position={[0, 0.01, 0]}>
        <sphereGeometry args={[0.05, 12, 12]} />
        <meshBasicMaterial color="#ffffff" />
      </mesh>

      {/* Grid unit labels along X */}
      {Array.from({ length: 5 }).map((_, i) => (
        <Text
          key={`xlabel-${i}`}
          position={[(i + 1) * 2, 0, 0.3]}
          fontSize={0.15}
          color="#666666"
          font="/fonts/GeistMono-Regular.ttf"
          anchorX="center"
          anchorY="middle"
        >
          {`${(i + 1) * 2}`}
        </Text>
      ))}

      {/* Grid unit labels along Z */}
      {Array.from({ length: 5 }).map((_, i) => (
        <Text
          key={`zlabel-${i}`}
          position={[0.3, 0, (i + 1) * 2]}
          fontSize={0.15}
          color="#666666"
          font="/fonts/GeistMono-Regular.ttf"
          anchorX="center"
          anchorY="middle"
        >
          {`${(i + 1) * 2}`}
        </Text>
      ))}
    </group>
  )
}
