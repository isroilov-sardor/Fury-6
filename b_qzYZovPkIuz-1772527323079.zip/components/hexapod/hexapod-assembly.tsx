"use client"

import { useCallback } from "react"
import { HexapodBody } from "./hexapod-body"
import { HexapodLeg, type JointAngles, type LegConfig } from "./hexapod-leg"

// ===== LEG CONFIGURATION =====
// 6 legs arranged around the hexagonal body
// Each leg has: mountAngle (where on body), mountPosition (3D coords), side
const LEG_CONFIGS: LegConfig[] = [
  {
    legIndex: 0,
    legName: "Left Leg 1 (Front-Left)",
    mountAngle: Math.PI / 3,        // 60 degrees
    mountPosition: [0.75, 0, 0.43],
    side: "left",
  },
  {
    legIndex: 1,
    legName: "Right Leg 1 (Front-Right)",
    mountAngle: -Math.PI / 3,       // -60 degrees
    mountPosition: [0.75, 0, -0.43],
    side: "right",
  },
  {
    legIndex: 2,
    legName: "Left Leg 2 (Mid-Left)",
    mountAngle: Math.PI / 2 + Math.PI / 6,  // 120 degrees
    mountPosition: [0, 0, 0.87],
    side: "left",
  },
  {
    legIndex: 3,
    legName: "Right Leg 2 (Mid-Right)",
    mountAngle: -(Math.PI / 2 + Math.PI / 6), // -120 degrees
    mountPosition: [0, 0, -0.87],
    side: "right",
  },
  {
    legIndex: 4,
    legName: "Left Leg 3 (Rear-Left)",
    mountAngle: Math.PI - Math.PI / 6,  // 150 degrees
    mountPosition: [-0.75, 0, 0.43],
    side: "left",
  },
  {
    legIndex: 5,
    legName: "Right Leg 3 (Rear-Right)",
    mountAngle: -(Math.PI - Math.PI / 6),  // -150 degrees
    mountPosition: [-0.75, 0, -0.43],
    side: "right",
  },
]

export { LEG_CONFIGS }

interface HexapodAssemblyProps {
  jointAnglesMap: Record<number, JointAngles>
  selectedJoint: string | null
  hoveredPart: string | null
  onJointHover: (id: string, hovered: boolean) => void
  onJointClick: (id: string) => void
  onPartHover: (id: string, hovered: boolean) => void
  onPartClick: (id: string) => void
}

export function HexapodAssembly({
  jointAnglesMap,
  selectedJoint,
  hoveredPart,
  onJointHover,
  onJointClick,
  onPartHover,
  onPartClick,
}: HexapodAssemblyProps) {

  const getJointAngles = useCallback(
    (legIndex: number): JointAngles => {
      return (
        jointAnglesMap[legIndex] || {
          coxa: 0,
          femur: -0.3,
          tibia: -0.6,
        }
      )
    },
    [jointAnglesMap]
  )

  return (
    <group position={[0, 1.5, 0]}>
      {/* Body */}
      <HexapodBody
        onHover={onPartHover}
        onClick={onPartClick}
        hoveredPart={hoveredPart}
      />

      {/* 6 Legs */}
      {LEG_CONFIGS.map((config) => (
        <HexapodLeg
          key={config.legIndex}
          config={config}
          jointAngles={getJointAngles(config.legIndex)}
          selectedJoint={selectedJoint}
          hoveredPart={hoveredPart}
          onJointHover={onJointHover}
          onJointClick={onJointClick}
          onPartHover={onPartHover}
          onPartClick={onPartClick}
        />
      ))}
    </group>
  )
}
