"use client"

import { useRef, useState } from "react"
import type { Mesh } from "three"
import type { ThreeEvent } from "@react-three/fiber"

interface LegSegmentProps {
  id: string
  length: number
  width?: number
  position?: [number, number, number]
  rotation?: [number, number, number]
  isHighlighted?: boolean
  onHover?: (id: string, hovered: boolean) => void
  onClick?: (id: string) => void
  variant?: "coxa" | "femur" | "tibia"
}

export function LegSegment({
  id,
  length,
  width = 0.12,
  position = [0, 0, 0],
  rotation = [0, 0, 0],
  isHighlighted = false,
  onHover,
  onClick,
  variant = "femur",
}: LegSegmentProps) {
  const meshRef = useRef<Mesh>(null)
  const [hovered, setHovered] = useState(false)

  const handlePointerOver = (e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation()
    setHovered(true)
    onHover?.(id, true)
    document.body.style.cursor = "pointer"
  }

  const handlePointerOut = (e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation()
    setHovered(false)
    onHover?.(id, false)
    document.body.style.cursor = "auto"
  }

  const handleClick = (e: ThreeEvent<MouseEvent>) => {
    e.stopPropagation()
    onClick?.(id)
  }

  const baseColor = hovered || isHighlighted ? "#4ecdc4" : "#3d3d5c"
  const metalColor = hovered || isHighlighted ? "#66d9ef" : "#555577"

  const bracketThickness = variant === "tibia" ? 0.08 : 0.1
  const segHeight = variant === "coxa" ? width * 1.2 : width

  return (
    <group position={position} rotation={rotation}>
      {/* Main structural beam - aluminum bracket */}
      <mesh
        ref={meshRef}
        position={[length / 2, 0, 0]}
        onPointerOver={handlePointerOver}
        onPointerOut={handlePointerOut}
        onClick={handleClick}
      >
        <boxGeometry args={[length, segHeight, bracketThickness]} />
        <meshStandardMaterial
          color={baseColor}
          metalness={0.85}
          roughness={0.15}
        />
      </mesh>

      {/* Side panel (U-bracket shape) */}
      <mesh position={[length / 2, 0, bracketThickness / 2 + 0.02]}>
        <boxGeometry args={[length * 0.9, segHeight * 0.6, 0.02]} />
        <meshStandardMaterial
          color={metalColor}
          metalness={0.8}
          roughness={0.2}
        />
      </mesh>
      <mesh position={[length / 2, 0, -(bracketThickness / 2 + 0.02)]}>
        <boxGeometry args={[length * 0.9, segHeight * 0.6, 0.02]} />
        <meshStandardMaterial
          color={metalColor}
          metalness={0.8}
          roughness={0.2}
        />
      </mesh>

      {/* Lightening holes / ventilation pattern */}
      {variant === "femur" &&
        Array.from({ length: 3 }).map((_, i) => (
          <mesh
            key={`hole-${i}`}
            position={[
              length * 0.25 + i * length * 0.25,
              0,
              bracketThickness / 2 + 0.025,
            ]}
          >
            <circleGeometry args={[0.025, 8]} />
            <meshStandardMaterial
              color="#222233"
              metalness={0.5}
              roughness={0.5}
            />
          </mesh>
        ))}

      {/* End pivot point - connection hole */}
      <mesh position={[length, 0, 0]} rotation={[0, 0, Math.PI / 2]}>
        <cylinderGeometry args={[0.04, 0.04, bracketThickness + 0.06, 12]} />
        <meshStandardMaterial color="#888899" metalness={0.9} roughness={0.1} />
      </mesh>

      {/* Start pivot point */}
      <mesh position={[0, 0, 0]} rotation={[0, 0, Math.PI / 2]}>
        <cylinderGeometry args={[0.04, 0.04, bracketThickness + 0.06, 12]} />
        <meshStandardMaterial color="#888899" metalness={0.9} roughness={0.1} />
      </mesh>

      {/* Rivets / bolts along the bracket */}
      {Array.from({
        length: Math.max(2, Math.floor(length / 0.3)),
      }).map((_, i) => {
        const count = Math.max(1, Math.floor(length / 0.3) - 1)
        return (
          <mesh
            key={`bolt-${i}`}
            position={[
              length * 0.15 + (i * length * 0.7) / count,
              segHeight / 2 + 0.01,
              0,
            ]}
          >
            <cylinderGeometry args={[0.012, 0.012, 0.02, 6]} />
            <meshStandardMaterial
              color="#cccccc"
              metalness={0.95}
              roughness={0.05}
            />
          </mesh>
        )
      })}
    </group>
  )
}
