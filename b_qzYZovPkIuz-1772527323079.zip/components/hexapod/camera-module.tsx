"use client"

import { useState } from "react"
import type { ThreeEvent } from "@react-three/fiber"

interface CameraModuleProps {
  id: string
  position?: [number, number, number]
  isHighlighted?: boolean
  onHover?: (id: string, hovered: boolean) => void
  onClick?: (id: string) => void
}

export function CameraModule({
  id,
  position = [0, 0, 0],
  isHighlighted = false,
  onHover,
  onClick,
}: CameraModuleProps) {
  const [hovered, setHovered] = useState(false)

  const handlePointerOver = (e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation()
    setHovered(true)
    onHover?.(id, true)
    document.body.style.cursor = "pointer"
  }

  const handlePointerOut = (e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation()
    setHovered(false)
    onHover?.(id, false)
    document.body.style.cursor = "auto"
  }

  const handleClick = (e: ThreeEvent<MouseEvent>) => {
    e.stopPropagation()
    onClick?.(id)
  }

  const lensColor = hovered || isHighlighted ? "#00bfff" : "#111122"
  const bodyColor = hovered || isHighlighted ? "#4488cc" : "#2a2a3e"

  return (
    <group position={position}>
      {/* Camera body - rectangular housing */}
      <mesh
        onPointerOver={handlePointerOver}
        onPointerOut={handlePointerOut}
        onClick={handleClick}
      >
        <boxGeometry args={[0.35, 0.25, 0.3]} />
        <meshStandardMaterial
          color={bodyColor}
          metalness={0.6}
          roughness={0.3}
        />
      </mesh>

      {/* Lens barrel */}
      <mesh position={[0, 0, 0.2]} rotation={[Math.PI / 2, 0, 0]}>
        <cylinderGeometry args={[0.1, 0.12, 0.15, 20]} />
        <meshStandardMaterial
          color="#1a1a2e"
          metalness={0.8}
          roughness={0.2}
        />
      </mesh>

      {/* Lens glass */}
      <mesh position={[0, 0, 0.28]} rotation={[Math.PI / 2, 0, 0]}>
        <cylinderGeometry args={[0.08, 0.08, 0.02, 20]} />
        <meshStandardMaterial
          color={lensColor}
          metalness={0.1}
          roughness={0.05}
          transparent
          opacity={0.8}
        />
      </mesh>

      {/* Lens ring */}
      <mesh position={[0, 0, 0.27]} rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[0.09, 0.01, 8, 20]} />
        <meshStandardMaterial color="#666688" metalness={0.9} roughness={0.1} />
      </mesh>

      {/* IR LEDs around lens */}
      {Array.from({ length: 8 }).map((_, i) => {
        const angle = (i / 8) * Math.PI * 2
        const r = 0.12
        return (
          <mesh
            key={`ir-${i}`}
            position={[Math.cos(angle) * r, Math.sin(angle) * r, 0.2]}
          >
            <sphereGeometry args={[0.012, 8, 8]} />
            <meshStandardMaterial
              color="#ff3333"
              emissive="#ff0000"
              emissiveIntensity={0.5}
            />
          </mesh>
        )
      })}

      {/* Status LED */}
      <mesh position={[0.12, 0.1, 0.151]}>
        <sphereGeometry args={[0.015, 8, 8]} />
        <meshStandardMaterial
          color="#00ff44"
          emissive="#00ff44"
          emissiveIntensity={1}
        />
      </mesh>

      {/* Mounting bracket */}
      <mesh position={[0, -0.15, 0]}>
        <boxGeometry args={[0.3, 0.04, 0.25]} />
        <meshStandardMaterial color="#444455" metalness={0.8} roughness={0.2} />
      </mesh>

      {/* Cable connector */}
      <mesh position={[-0.18, 0, -0.08]}>
        <boxGeometry args={[0.04, 0.1, 0.08]} />
        <meshStandardMaterial color="#222233" metalness={0.3} roughness={0.7} />
      </mesh>
    </group>
  )
}
