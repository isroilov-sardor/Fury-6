"use client"

import dynamic from "next/dynamic"

const HexapodScene = dynamic(
  () =>
    import("@/components/hexapod/hexapod-scene").then(
      (mod) => mod.HexapodScene
    ),
  {
    ssr: false,
    loading: () => (
      <div
        className="flex h-screen w-full items-center justify-center"
        style={{ background: "#1a1a2e" }}
      >
        <div className="flex flex-col items-center gap-4">
          <div
            className="h-10 w-10 animate-spin rounded-full border-2 border-t-[#ff6b35]"
            style={{ borderColor: "#333", borderTopColor: "#ff6b35" }}
          />
          <span className="text-sm" style={{ color: "#888" }}>
            Initializing 3D Hexapod Viewer...
          </span>
        </div>
      </div>
    ),
  }
)

export default function HexapodPage() {
  return (
    <main className="h-screen w-full overflow-hidden">
      <HexapodScene />
    </main>
  )
}
